from django.apps import AppConfig


class RestFConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rest_f'
